import tkinter as tk # x as tk
from tkinter import messagebox #1 step for messagebox
import parcel_calculator
import mysql.connector

class  ParcelCalculatorGUI: #class x :
 def __init__(self, master):
    self.master = master
    master.title("Parcel Calculator")
    master.configure(bg='#FFE4C4') #set bg color

    # Create length input label and entry field
    self.length_label = tk.Label(master, text="Length (cm):", bg='#FFE4C4')
    self.length_label.grid(row=0, column=0, padx=10, pady=5)
    self.length_entry = tk.Entry(master)
    self.length_entry.grid(row=0, column=1, padx=10, pady=5)

    # Create width input label and entry field
    self.width_label = tk.Label(master, text="Width (cm):", bg='#FFE4C4')
    self.width_label.grid(row=1, column=0, padx=10, pady=5)
    self.width_entry = tk.Entry(master)
    self.width_entry.grid(row=1, column=1, padx=10, pady=5)

    # Create height input label and entry field
    self.height_label = tk.Label(master, text="Height (cm):", bg='#FFE4C4')
    self.height_label.grid(row=2, column=0, padx=10, pady=5)
    self.height_entry = tk.Entry(master)
    self.height_entry.grid(row=2, column=1, padx=10, pady=5)

    # Create weight input label and entry field
    self.weight_label = tk.Label(master, text="Weight (kg):", bg='#FFE4C4')
    self.weight_label.grid(row=3, column=0, padx=10, pady=5)
    self.weight_entry = tk.Entry(master)
    self.weight_entry.grid(row=3, column=1, padx=10, pady=5)

    # Create calculate button
    self.calculate_button = tk.Button(master, text="Calculate", command=self.calculate_price, bg='#4CAF50', fg='white')
    self.calculate_button.grid(row=4, column=0, columnspan=2, pady=10)

    # Create save to database button
    self.save_button = tk.Button(master, text="Save to Database", command=self.save_to_database, bg='#2196F3', fg='white')
    self.save_button.grid(row=5, column=0, columnspan=2, pady=10)

    # Create reset button
    self.reset_button = tk.Button(master, text="Reset", command=self.reset_fields, bg='#f44336', fg='white')
    self.reset_button.grid(row=6, column=0, columnspan=2, pady=10)

    # Create price label
    self.price_label = tk.Label(master, text="", bg='#FFE4C4', font=('Arial', 12, 'bold'))
    self.price_label.grid(row=7, column=0, columnspan=2, pady=10)

def calculate_price(self):
    try:
        # Get parcel dimensions and weight from entry fields
        length = float(self.length_entry.get())
        width = float(self.width_entry.get())
        height = float(self.height_entry.get())
        weight = float(self.weight_entry.get())

    # Calculate parcel price using imported function
    price = parcel_calculator.calculate_price(length, width, height, weight)

    # Update price label with calculated price
    self.price_label.config(text="The price of your parcel is: $" + str(price))

    # Show message box with calculated price
    messagebox.showinfo("Price Calculation", f"The price of your parcel is: ${price}")

    # Store calculated price in an instance variable for database insertion
    self.calculated_price = price
    
    except ValueError:
    messagebox.showerror("Input Error", "Please enter valid numbers for all fields.")

def reset_fields(self):
    # Clear all entry fields and price label
    self.length_entry.delete(0, tk.END)
    self.width_entry.delete(0, tk.END)
    self.height_entry.delete(0, tk.END)
    self.weight_entry.delete(0, tk.END)
    self.price_label.config(text="")

def save_to_database(self):
    try:
        # Get parcel dimensions and weight from entry fields
        item_id = self.length_entry.get() + self.width_entry.get() + self.height_entry.get()  # Generate a simple ID
        length = self.length_entry.get()
        width = self.width_entry.get()
        height = self.height_entry.get()
        volume = str(float(length) * float(width) * float(height))
        price = str(self.calculated_price)

    # Connect to the MySQL database
    conn = mysql.connector.connect(
        host="localhost",
        user="your_username",
        password="your_password",
        database="LelemoveSystem"
    )
    cursor = conn.cursor()

    # Insert data into the parcels table
    cursor.execute("INSERT INTO parcels (item_id, item_height, item_width, item_length, item_volume, item_price) VALUES (%s, %s, %s, %s, %s, %s)", 
                    (item_id, height, width, length, volume, price))

# Commit the transaction
    conn.commit()

    # Close the connection
    cursor.close()
    conn.close()

    messagebox.showinfo("Record Success", "Your application has been submitted.")

    except mysql.connector.Error as err:
    messagebox.showerror("Database Error", f"Error: {err}")

    except Exception as e:
    messagebox.showerror("Error", f"An error occurred: {e}")

 # Update price label with calculated price
    self.price_label.config(text="The price of your parcel is: $" + str(price)) #str( x ))
root = tk.Tk() #x = tk.Tk()
parcel_calculator_gui = ParcelCalculatorGUI(a)
a.mainloop()