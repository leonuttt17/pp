import tkinter as tk
from tkinter import messagebox, ttk
import mysql.connector

# Database setup
def setup_database():
    conn = mysql.connector.connect(
        host="localhost",
        user="your_username",
        password="your_password"
    )
    cursor = conn.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS LelemoveSystem")
    cursor.execute("USE LelemoveSystem")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS parcels (
            item_id VARCHAR(10) PRIMARY KEY,
            item_name VARCHAR(50),
            item_category VARCHAR(50),
            item_option VARCHAR(50),
            item_status VARCHAR(50)
        )
    """)
    conn.close()

# Initialize database
setup_database()

class ParcelApp:
    def __init__(self, master):
        self.master = master
        master.title("Parcel Management System")

        self.current_frame = None
        self.show_frame(HomePage)

    def show_frame(self, frame_class):
        new_frame = frame_class(self)
        if self.current_frame is not None:
            self.current_frame.destroy()
        self.current_frame = new_frame
        self.current_frame.pack()

class HomePage(tk.Frame):
    def __init__(self, app):
        tk.Frame.__init__(self, app.master)
        self.app = app

        tk.Label(self, text="Home Page", font=("Arial", 16)).pack(pady=10)
        
        tk.Button(self, text="Go to Input Page", command=lambda: app.show_frame(InputPage)).pack(pady=10)

class InputPage(tk.Frame):
    def __init__(self, app):
        tk.Frame.__init__(self, app.master)
        self.app = app

        tk.Label(self, text="Input Page", font=("Arial", 16)).pack(pady=10)
        
        # Entry with Label
        tk.Label(self, text="Name:").pack(pady=5)
        self.name_entry = tk.Entry(self)
        self.name_entry.pack(pady=5)

        # Dropdown menu
        tk.Label(self, text="Category:").pack(pady=5)
        self.category_var = tk.StringVar()
        self.category_dropdown = ttk.Combobox(self, textvariable=self.category_var)
        self.category_dropdown['values'] = ("Electronics", "Clothing", "Books")
        self.category_dropdown.pack(pady=5)

        # Checkbox
        tk.Label(self, text="Options:").pack(pady=5)
        self.option_var = tk.StringVar()
        self.option_checkbox = tk.Checkbutton(self, text="Option 1", variable=self.option_var, onvalue="Option 1", offvalue="")
        self.option_checkbox.pack(pady=5)

        # Radio buttons
        tk.Label(self, text="Status:").pack(pady=5)
        self.status_var = tk.StringVar()
        self.status_radiobutton1 = tk.Radiobutton(self, text="New", variable=self.status_var, value="New")
        self.status_radiobutton2 = tk.Radiobutton(self, text="Used", variable=self.status_var, value="Used")
        self.status_radiobutton1.pack(pady=5)
        self.status_radiobutton2.pack(pady=5)

        # Action buttons
        tk.Button(self, text="Add", command=self.add_record).pack(pady=5)
        tk.Button(self, text="Delete", command=self.delete_record).pack(pady=5)
        tk.Button(self, text="Back to Home", command=lambda: app.show_frame(HomePage)).pack(pady=5)

    def add_record(self):
        name = self.name_entry.get()
        category = self.category_var.get()
        option = self.option_var.get()
        status = self.status_var.get()
        item_id = name[:2] + category[:2] + status[:2]  # Simple item_id generation
        
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="your_username",
                password="your_password",
                database="LelemoveSystem"
            )
            cursor = conn.cursor()
            cursor.execute("INSERT INTO parcels (item_id, item_name, item_category, item_option, item_status) VALUES (%s, %s, %s, %s, %s)", 
                           (item_id, name, category, option, status))
            conn.commit()
            cursor.close()
            conn.close()
            messagebox.showinfo("Success", "Record added successfully!")
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    def delete_record(self):
        name = self.name_entry.get()
        category = self.category_var.get()
        status = self.status_var.get()
        item_id = name[:2] + category[:2] + status[:2]  # Simple item_id generation
        
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="your_username",
                password="your_password",
                database="LelemoveSystem"
            )
            cursor = conn.cursor()
            cursor.execute("DELETE FROM parcels WHERE item_id=%s", (item_id,))
            conn.commit()
            cursor.close()
            conn.close()
            messagebox.showinfo("Success", "Record deleted successfully!")
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

if __name__ == "__main__":
    root = tk.Tk()
    app = ParcelApp(root)
    root.mainloop()