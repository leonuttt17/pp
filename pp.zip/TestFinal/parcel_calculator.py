def calculate_price (length, width, height, weight) :

    volume = length * width * height

    if weight <= 1 :
        if volume <= 5000:
            price = 3
        elif volume <= 10000:
            price = 5
        else : 
            price = 7

    elif weight <= 5:
        if volume <= 5000:
            price = 5
        elif volume <= 10000:
            price = 7
        else : 
            price = 9

    else :
        if volume <= 5000:
            price = 7
        elif volume <= 10000:
            price = 9
        else : 
            price = 11

    return price

def save_parcel_details(length, width, height, weight):
    with open ("parcel_details.txt", "a") as file:
        file.write(f"Length: {length} cm, Width: {width} cm, Height : {height}cm, Weight : {weight} kg\n")